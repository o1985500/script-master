import google.generativeai as genai

# ==========================================
# 🔑 ใส่ API KEY ของคุณตรงนี้เพื่อเช็ก
# ==========================================
API_KEY = "AIzaSyBQvAIvn4xXW1VbaKCbzwW2UETna04HTgc"

genai.configure(api_key=API_KEY)

print("\n--- กำลังตรวจสอบรายชื่อโมเดล... ---")
try:
    count = 0
    for m in genai.list_models():
        # กรองเฉพาะโมเดลที่สร้างข้อความได้ (generateContent)
        if 'generateContent' in m.supported_generation_methods:
            print(f"✅ พบโมเดล: {m.name}")
            count += 1
    
    if count == 0:
        print("❌ ไม่พบโมเดลที่ใช้งานได้ (อาจเป็นที่สิทธิ์ของ API Key หรือ Region)")
    else:
        print(f"\n--- ทั้งหมด {count} โมเดล ---")

except Exception as e:
    print(f"\n❌ เกิดข้อผิดพลาด: {e}")