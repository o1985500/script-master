import os
import io
import json
import requests # ใช้ requests แทน mistralai SDK
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from gtts import gTTS
from dotenv import load_dotenv

# 1. โหลดค่าจากไฟล์ .env
load_dotenv()

app = Flask(__name__)
CORS(app)

# 2. ดึง API Key
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY")

@app.route('/generate-script', methods=['POST'])
def generate_script():
    try:
        if not MISTRAL_API_KEY:
            return jsonify({"error": "MISTRAL_API_KEY not found on server"}), 500

        data = request.json
        
        # ดึงข้อมูลจากโครงสร้างที่ Frontend ส่งมา
        contents = data.get('contents', [])
        sys_instruct_data = data.get('systemInstruction', {})
        
        sys_message = "You are a creative director."
        if 'parts' in sys_instruct_data and len(sys_instruct_data['parts']) > 0:
            sys_message = sys_instruct_data['parts'][0].get('text', sys_message)

        user_text = ""
        if contents and len(contents) > 0:
            parts = contents[0].get('parts', [])
            if parts:
                user_text = parts[0].get('text', '')

        # 3. เรียกใช้ Mistral API โดยตรงผ่าน requests (ไม่ต้องพึ่ง SDK)
        url = "https://api.mistral.ai/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {MISTRAL_API_KEY}"
        }
        payload = {
            "model": "mistral-large-latest",
            "messages": [
                {"role": "system", "content": sys_message},
                {"role": "user", "content": user_text}
            ],
            "response_format": {"type": "json_object"}
        }

        response = requests.post(url, headers=headers, json=payload)
        response_data = response.json()
        
        if response.status_code != 200:
            return jsonify({"error": response_data}), response.status_code

        result_text = response_data['choices'][0]['message']['content']
        
        # 4. ส่งกลับในรูปแบบที่ Frontend (Vite) ของคุณรองรับ
        return jsonify({
            "candidates": [
                {
                    "content": {
                        "parts": [{"text": result_text}]
                    }
                }
            ]
        })

    except Exception as e:
        print(f"Server Error: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/generate-voice', methods=['POST'])
def generate_voice():
    try:
        data = request.json
        text = data.get('text', '')
        if not text: return jsonify({"error": "No text"}), 400
        
        tts = gTTS(text=text, lang='th', slow=False)
        fp = io.BytesIO()
        tts.write_to_fp(fp)
        fp.seek(0)
        
        return send_file(fp, mimetype='audio/mpeg')
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # รันที่พอร์ต 5000
    app.run(host='0.0.0.0', port=5000, debug=True)